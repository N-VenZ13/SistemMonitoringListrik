<?php $__env->startComponent('mail::message'); ?>
# Peringatan: Pemakaian Listrik Mendekati Batas!

Halo,

Sistem monitoring listrik kami mendeteksi bahwa pemakaian listrik Anda saat ini telah mencapai **<?php echo e($approachingThresholdPercent); ?>%** dari batas yang telah ditetapkan dan sudah **mendekati batas target**.

**Detail Pemakaian Saat Ini:**
- Energi Terpakai: **<?php echo e($currentEnergy); ?> kWh**
- Estimasi Biaya Saat Ini: **Rp <?php echo e($currentCost); ?>**

**Batas Target yang Ditetapkan:**
<?php if($limitType === 'energy'): ?>
- Batas Energi Target: **<?php echo e($energyLimit); ?> kWh**
<?php else: ?>
- Batas Biaya Target: **Rp <?php echo e($costLimit); ?>** (Perkiraan setara dengan <?php echo e($energyLimit); ?> kWh)
<?php endif; ?>

Mohon untuk mulai memperhatikan penggunaan perangkat listrik Anda agar konsumsi tidak melebihi batas.

<?php $__env->startComponent('mail::button', ['url' => $monitoringUrl, 'color' => 'warning']); ?>
Lihat Dashboard Monitoring
<?php echo $__env->renderComponent(); ?>

Terima kasih,<br>
Tim <?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\Users\User\Downloads\download\setengah\Allbright-batch-7\laravell\monitoring-listrik-ver2\resources\views/emails/approaching_usage_limit.blade.php ENDPATH**/ ?>