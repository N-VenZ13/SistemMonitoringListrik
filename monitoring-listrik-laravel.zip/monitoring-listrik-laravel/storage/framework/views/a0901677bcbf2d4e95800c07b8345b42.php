<?php $__env->startComponent('mail::message'); ?>
# Peringatan Batas Pemakaian Listrik Terlampaui!

Halo,

Sistem monitoring listrik kami mendeteksi bahwa pemakaian listrik Anda telah melebihi batas yang telah ditetapkan.

**Detail Pemakaian Saat Ini:**
- Energi Terpakai: **<?php echo e($currentEnergy); ?> kWh**
- Estimasi Biaya Saat Ini: **Rp <?php echo e($currentCost); ?>**

**Batas yang Ditetapkan:**
<?php if($limitType === 'energy'): ?>
- Batas Energi: **<?php echo e($energyLimit); ?> kWh**
<?php elseif($limitType === 'cost' && isset($costLimit)): ?>
- Batas Biaya: **Rp <?php echo e($costLimit); ?>** (Perkiraan setara dengan <?php echo e($energyLimit); ?> kWh pada tarif saat ini)
<?php else: ?>
- Batas Energi (dihitung): **<?php echo e($energyLimit); ?> kWh**
<?php endif; ?>

Mohon untuk segera memeriksa penggunaan perangkat listrik Anda untuk mengelola konsumsi agar tidak melebihi anggaran atau target pemakaian energi Anda.

Anda dapat melihat detail penggunaan dan mengelola pengaturan melalui dashboard monitoring kami.

<?php $__env->startComponent('mail::button', ['url' => $monitoringUrl, 'color' => 'primary']); ?>
Lihat Dashboard Monitoring
<?php echo $__env->renderComponent(); ?>

Terima kasih atas perhatian Anda.

Hormat kami,<br>
Tim <?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\Users\User\Downloads\download\setengah\Allbright-batch-7\laravell\monitoring-listrik-ver2\resources\views/emails/usage_limit_exceeded.blade.php ENDPATH**/ ?>