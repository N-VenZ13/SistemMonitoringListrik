<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\User\Downloads\download\setengah\Allbright-batch-7\laravell\monitoring-listrik-ver2\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>