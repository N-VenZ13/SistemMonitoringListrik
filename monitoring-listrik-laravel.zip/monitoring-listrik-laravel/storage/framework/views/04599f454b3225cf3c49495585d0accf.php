<?php $__env->startComponent('mail::message'); ?>
# Informasi: Pemakaian Listrik Kembali Normal

Halo,

Sistem monitoring listrik kami menginformasikan bahwa pemakaian listrik Anda saat ini telah kembali ke tingkat normal (di bawah ambang batas peringatan).

**Detail Pemakaian Saat Ini:**
- Energi Terpakai: **<?php echo e($currentEnergy); ?> kWh**
- Estimasi Biaya Saat Ini: **Rp <?php echo e($currentCost); ?>**

Terima kasih telah mengelola penggunaan energi Anda.

<?php $__env->startComponent('mail::button', ['url' => $monitoringUrl, 'color' => 'success']); ?>
Lihat Dashboard Monitoring
<?php echo $__env->renderComponent(); ?>

Salam hemat energi,<br>
Tim <?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\Users\User\Downloads\download\setengah\Allbright-batch-7\laravell\monitoring-listrik-ver2\resources\views/emails/usage_normal_again.blade.php ENDPATH**/ ?>