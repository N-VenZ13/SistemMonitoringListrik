<?php

use App\Http\Controllers\PzemController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


// Halaman untuk mengatur batas pemakaian
Route::get('/settings/limit', [PzemController::class, 'getLimitSettingsPage'])->name('settings.limit.show');

// Endpoint untuk ESP32 mengambil konfigurasi batas
Route::get('/limit/config', [PzemController::class, 'getLimitConfigForEsp'])->name('limit.config.esp');

// Endpoint untuk Web UI (JS) mengambil dan mengupdate data konfigurasi batas
Route::get('/settings/limit/data', [PzemController::class, 'getLimitConfigData'])->name('settings.limit.data.api');
Route::post('/settings/limit/update', [PzemController::class, 'updateLimitConfig'])->name('settings.limit.update.api');

// Endpoint untuk ESP32 mengirim data sensor
Route::post('/pzem/store', [PzemController::class, 'store'])
      ->name('pzem.store'); // Opsional: beri nama juga jika perlu

// Endpoint untuk ESP32 mengambil status relay
Route::get('/relay/status', [PzemController::class, 'getRelayStatus'])
     ->name('relay.status'); // Opsional: beri nama juga jika perlu

// Endpoint untuk Frontend (JS) mengirim perintah kontrol relay
Route::post('/relay/control', [PzemController::class, 'updateRelayStatus'])
      ->name('relay.control'); // <-- Nama ditambahkan di sini


// Endpoint untuk Frontend (JS) mengirim perintah reset energi PZEM
Route::post('/pzem/command/reset-energy', [App\Http\Controllers\PzemController::class, 'issuePzemResetCommand'])
      ->name('pzem.command.reset');

// Default route /user (biasanya untuk auth API, bisa dihapus jika tidak pakai Sanctum)
// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });