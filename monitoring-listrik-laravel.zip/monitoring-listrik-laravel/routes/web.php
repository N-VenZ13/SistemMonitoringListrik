<?php

use App\Http\Controllers\PzemController;
use Illuminate\Support\Facades\Route;

// Halaman utama dashboard monitoring
Route::get('/monitor', function () {
    // View hanya akan menampilkan kerangka HTML dan JS
    // Data akan di-load oleh JavaScript secara asynchronous
    return view('monitor');
})->name('monitor.index'); // Beri nama route jika perlu

// Endpoint untuk JavaScript di frontend melakukan polling data terbaru
Route::get('/data-monitor', [PzemController::class, 'getLatestDataAndStatus'])
    ->name('monitor.data'); // Beri nama route jika perlu

    Route::get('/limit', function () {
    // View hanya akan menampilkan kerangka HTML dan JS
    // Data akan di-load oleh JavaScript secara asynchronous
    return view('limit');
})->name('limit.index'); // Beri nama route jika perlu

// Route default Laravel
// Route::get('/', function () {
//     return view('welcome');
// });


// ==========================================================

use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;
// use Illuminate\Mail\Message; // <-- Tambahkan ini

// Route::get('/simple-email-test', function () {
//     $recipient = env('NOTIFICATION_EMAIL_RECIPIENT', 'vevenz13@gmail.com'); // Ambil dari env, atau fallback
//     $fromAddressToTest = 'staycool006@gmail.com'; // <-- HARDCODE ALAMAT PENGIRIM DI SINI
//     $fromNameToTest = 'Monitoring Tes IoT';    // <-- HARDCODE NAMA PENGIRIM DI SINI

//     if (!$recipient || !filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
//         $errorMessage = "Error: NOTIFICATION_EMAIL_RECIPIENT tidak valid atau tidak diset. Menggunakan fallback jika ada, atau gagal.";
//         Log::error('[SIMPLE_TEST_ERROR] ' . $errorMessage, ['recipient_env' => env('NOTIFICATION_EMAIL_RECIPIENT')]);
//         return $errorMessage;
//     }

//     $subject = "Tes Email Sederhana (HARDCODED FROM) dari Laravel IoT";
//     $body = "Ini adalah email tes sederhana untuk memverifikasi konfigurasi SMTP dengan alamat 'From' yang di-hardcode.";

//     Log::debug('[SIMPLE_TEST_HARDCODE] Akan mencoba mengirim ke: ' . $recipient . ' DARI: ' . $fromAddressToTest);

//     try {
//         Mail::raw($body, function (Message $message) use ($recipient, $fromAddressToTest, $fromNameToTest, $subject) {
//             $message->to($recipient)
//                     ->from($fromAddressToTest, $fromNameToTest) // <-- Menggunakan variabel yang di-hardcode
//                     ->subject($subject);
//         });
//         Log::info('[SIMPLE_TEST_HARDCODE] Email tes sederhana (dengan From di-hardcode) BERHASIL DIKIRIM (menurut Laravel) ke: ' . $recipient . ' dari: ' . $fromAddressToTest);
//         return "Percobaan pengiriman email tes sederhana (dengan From di-hardcode) ke " . $recipient . " telah dilakukan. Cek log dan inbox (termasuk spam).";
//     } catch (\Exception $e) {
//         Log::error('[SIMPLE_TEST_HARDCODE] Gagal mengirim email tes sederhana (dengan From di-hardcode).', [
//             'error' => $e->getMessage(),
//             'recipient' => $recipient,
//             'from' => $fromAddressToTest
//         ]);
//         return "Gagal mengirim email tes sederhana (dengan From di-hardcode): " . $e->getMessage();
//     }
// });

Route::get('/simple-email-test', function () {
    $recipient = env('NOTIFICATION_EMAIL_RECIPIENT');
    $fromAddress = env('MAIL_FROM_ADDRESS');
    $fromName = env('MAIL_FROM_NAME', config('app.name')); // Ambil dari config app.name jika MAIL_FROM_NAME tdk ada di .env

    if (!$recipient || !filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
        return "Error: NOTIFICATION_EMAIL_RECIPIENT tidak valid atau tidak diset di .env.";
    }
    if (!$fromAddress || !filter_var($fromAddress, FILTER_VALIDATE_EMAIL)) {
        return "Error: MAIL_FROM_ADDRESS tidak valid atau tidak diset di .env.";
    }

    $subject = "Tes Email Sederhana dari Laravel IoT";
    $body = "Ini adalah email tes sederhana untuk memverifikasi konfigurasi SMTP.";

    try {
        Mail::raw($body, function ($message) use ($recipient, $fromAddress, $fromName, $subject) {
            $message->to($recipient)
                    ->from($fromAddress, $fromName) // Penting: from() harus dipanggil
                    ->subject($subject);
        });
        Log::info('[SIMPLE_TEST] Email tes sederhana BERHASIL dikirim (menurut Laravel) ke: ' . $recipient . ' dari: ' . $fromAddress);
        return "Percobaan pengiriman email tes sederhana ke " . $recipient . " telah dilakukan. Cek log dan inbox (termasuk spam).";
    } catch (\Exception $e) {
        Log::error('[SIMPLE_TEST] Gagal mengirim email tes sederhana.', [
            'error' => $e->getMessage(),
            'recipient' => $recipient,
            'from' => $fromAddress
        ]);
        return "Gagal mengirim email tes sederhana: " . $e->getMessage();
    }
});

// Route untuk halaman histori
Route::get('/history', [App\Http\Controllers\PzemController::class, 'showHistory'])->name('history.show');