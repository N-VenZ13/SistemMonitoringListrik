<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('pzem_data', function (Blueprint $table) {
            $table->id();
            $table->float('tegangan'); // Sesuai key JSON dari ESP32
            $table->float('arus');     // Sesuai key JSON dari ESP32
            $table->float('daya');     // Sesuai key JSON dari ESP32
            $table->float('energi');   // Sesuai key JSON dari ESP32
            $table->decimal('biaya', 10, 2); // Kolom untuk biaya yang dihitung
            $table->timestamps(); // Otomatis membuat created_at dan updated_at
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('pzem_data');
    }
};
