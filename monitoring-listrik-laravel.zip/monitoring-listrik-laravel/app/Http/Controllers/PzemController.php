<?php

namespace App\Http\Controllers;

use App\Models\PzemData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Mail;
use App\Mail\UsageLimitExceededMail;
use App\Mail\ApproachingUsageLimitMail;
use App\Mail\UsageNormalAgainMail;
use Illuminate\Support\Facades\DB; // Penting untuk query agregasi


class PzemController extends Controller
{
    // --- Path untuk file konfigurasi dan status ---
    private $relayStatusFilePath = 'relay_status.json';
    private $limitConfigFilePath = 'limit_config.json';
    private $emailNotificationStatusPath = 'email_notification_status.json';

    // Definisikan threshold "mendekati batas" (misal, 85%)
    private const APPROACHING_LIMIT_THRESHOLD = 0.85;

    /**
     * Menyimpan data sensor yang diterima dari ESP32, memicu pengecekan notifikasi.
     * Endpoint: POST /api/pzem/store
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'tegangan' => 'required|numeric|min:0',
            'arus'     => 'required|numeric|min:0',
            'daya'     => 'required|numeric|min:0',
            'energi'   => 'required|numeric|min:0',
        ]);

        $costPerKwh = (float) env('COST_PER_KWH', 1444.70);
        $currentEnergy = (float) $validatedData['energi'];
        $currentCost   = $currentEnergy * $costPerKwh;

        $dataToStore          = $validatedData;
        $dataToStore['biaya'] = $currentCost;

        try {
            $pzemData = PzemData::create($dataToStore);
            Log::info('Pzem data stored.', ['id' => $pzemData->id, 'energy' => $currentEnergy, 'cost' => $currentCost]);

            // Panggil fungsi baru untuk notifikasi email bertingkat
            $this->checkAndSendTieredUsageLimitEmail($currentEnergy, $currentCost);

            return response()->json(['message' => 'Data sensor berhasil disimpan', 'data'    => $pzemData], 201);
        } catch (\Exception $e) {
            Log::error('Failed to store Pzem data or process notifications.', ['error' => $e->getMessage(),'data'  => $dataToStore]);
            return response()->json(['message' => 'Gagal memproses data sensor'], 500);
        }
    }

    /**
     * Mengambil status relay terakhir dari file JSON.
     * Dipakai oleh ESP32.
     * Endpoint: GET /api/relay/status
     */
    // public function getRelayStatus()
    // {
    //     return response()->json($this->readRelayStatus());
    // }

    public function getRelayStatus() // Method ini akan dipanggil oleh ESP32
    {
        $status = $this->readRelayStatus();

        // Setelah ESP32 mengambil status, jika ada perintah reset, kita asumsikan ESP32 akan segera memprosesnya.
        // Maka, kita bisa langsung mereset flag 'reset_pzem_energy' kembali ke false di server.
        // Ini mencegah ESP32 mereset berulang kali jika ia mengambil status beberapa kali sebelum berhasil reset.
        if ($status['reset_pzem_energy'] === true) {
            Log::info('[PZEM_RESET] Flag reset_pzem_energy was true, ESP32 is expected to process. Resetting flag on server.');
            $statusToSave = $status; // Salin status saat ini
            $statusToSave['reset_pzem_energy'] = false; // Set flag reset kembali ke false
            try {
                Storage::disk('local')->put($this->relayStatusFilePath, json_encode($statusToSave, JSON_PRETTY_PRINT));
                Log::info('[PZEM_RESET] Server-side reset_pzem_energy flag has been reset to false after being read by ESP32.');
            } catch (\Exception $e) {
                Log::error('[PZEM_RESET] Failed to auto-reset reset_pzem_energy flag on server.', ['error' => $e->getMessage()]);
            }
        }
        // Kembalikan status yang *sebelum* flag direset di server, agar ESP32 mendapatkan perintah true sekali.
        return response()->json($status);
    }

    /**
     * Memperbarui status relay (lampu) berdasarkan perintah dari frontend.
     * Endpoint: POST /api/relay/control
     */
    // public function updateRelayStatus(Request $request)
    // {
    //     $validatedData = $request->validate([
    //         'relay1' => ['required', Rule::in(['HIGH', 'LOW'])], // Tetap terima, tapi mungkin tidak digunakan UI
    //         'relay2' => ['required', Rule::in(['HIGH', 'LOW'])], // Untuk lampu
    //     ]);

    //     $newStatus = [
    //         'relay1' => $validatedData['relay1'], // Simpan status relay1 (misal, selalu 'LOW' dari frontend)
    //         'relay2' => $validatedData['relay2'],
    //     ];

    //     // Jika lampu dinyalakan manual saat sebelumnya mati otomatis karena limit
    //     $limitConfig = $this->readLimitConfig();
    //     if ($validatedData['relay2'] === 'HIGH' && $limitConfig['light_auto_turned_off']) {
    //         Log::info('[ManualLightON] Lampu dinyalakan manual, reset flag light_auto_turned_off.');
    //         $limitConfig['light_auto_turned_off'] = false;
    //         $this->writeLimitConfig($limitConfig);
    //     }

    //     try {
    //         Storage::disk('local')->put($this->relayStatusFilePath, json_encode($newStatus, JSON_PRETTY_PRINT));
    //         Log::info('Relay status updated.', $newStatus);
    //         return response()->json(['message' => 'Status relay berhasil diperbarui', 'data'    => $newStatus]);
    //     } catch (\Exception $e) {
    //         Log::error('Failed to update relay status file.', ['error'  => $e->getMessage(), 'status' => $newStatus]);
    //         return response()->json(['message' => 'Gagal memperbarui status relay'], 500);
    //     }
    // }


    public function updateRelayStatus(Request $request)
    {
        $validatedData = $request->validate([
            'relay1' => ['required', Rule::in(['HIGH', 'LOW'])],
            'relay2' => ['required', Rule::in(['HIGH', 'LOW'])],
        ]);

        $currentStatus = $this->readRelayStatus(); // Baca status saat ini (termasuk flag reset)

        $newStatus = [
            'relay1' => $validatedData['relay1'],
            'relay2' => $validatedData['relay2'],
            'reset_pzem_energy' => $currentStatus['reset_pzem_energy'] // Pertahankan flag reset saat ini
        ];

        // ... (logika light_auto_turned_off jika lampu dinyalakan manual tetap sama) ...
        $limitConfig = $this->readLimitConfig();
        if ($validatedData['relay2'] === 'HIGH' && $limitConfig['light_auto_turned_off']) {
            Log::info('[ManualLightON] Lampu dinyalakan manual, reset flag light_auto_turned_off.');
            $limitConfig['light_auto_turned_off'] = false;
            $this->writeLimitConfig($limitConfig);
        }


        try {
            Storage::disk('local')->put($this->relayStatusFilePath, json_encode($newStatus, JSON_PRETTY_PRINT));
            Log::info('Relay status updated (lamp control).', $newStatus);
            return response()->json(['message' => 'Status lampu berhasil diperbarui', 'data'    => $newStatus]);
        } catch (\Exception $e) {
            Log::error('Failed to update relay status file (lamp control).', ['error'  => $e->getMessage(), 'status' => $newStatus]);
            return response()->json(['message' => 'Gagal memperbarui status lampu'], 500);
        }
    }


    public function issuePzemResetCommand(Request $request)
    {
        $currentStatus = $this->readRelayStatus(); // Baca status relay dan perintah saat ini
        $newStatus = [
            'relay1' => $currentStatus['relay1'],
            'relay2' => $currentStatus['relay2'],
            'reset_pzem_energy' => true // Set flag untuk mereset PZEM
        ];

        try {
            Storage::disk('local')->put($this->relayStatusFilePath, json_encode($newStatus, JSON_PRETTY_PRINT));
            Log::info('[PZEM_RESET] Command to reset PZEM energy issued by web.', $newStatus);
            return response()->json(['message' => 'Perintah reset energi PZEM berhasil dikirim ke perangkat.']);
        } catch (\Exception $e) {
            Log::error('[PZEM_RESET] Failed to issue PZEM reset command.', [
                'error'  => $e->getMessage(),
                'status' => $newStatus
            ]);
            return response()->json(['message' => 'Gagal mengirim perintah reset energi PZEM.'], 500);
        }
    }


    /**
     * Mengambil data sensor terbaru DAN status relay terakhir untuk frontend.
     * Endpoint: GET /data-monitor (web route)
     */
    public function getLatestDataAndStatus()
    {
        $latestSensorData = PzemData::latest()->first();
        $relayStatus      = $this->readRelayStatus();
        $responseData     = ['sensor' => $latestSensorData, 'relay'  => $relayStatus];
        return response()->json($responseData);
    }

    /**
     * Helper function untuk membaca status relay dari file JSON.
     */
    // private function readRelayStatus(): array
    // {
    //     $defaultStatus = ['relay1' => 'LOW', 'relay2' => 'LOW'];
    //     try {
    //         if (!Storage::disk('local')->exists($this->relayStatusFilePath)) {
    //             Storage::disk('local')->put($this->relayStatusFilePath, json_encode($defaultStatus, JSON_PRETTY_PRINT));
    //             return $defaultStatus;
    //         }
    //         $jsonContent = Storage::disk('local')->get($this->relayStatusFilePath);
    //         $status      = json_decode($jsonContent, true);

    //         if (json_last_error() !== JSON_ERROR_NONE || !is_array($status)) {
    //             Log::error('Failed to decode relay status JSON or invalid format. Writing default.', ['content' => $jsonContent]);
    //             Storage::disk('local')->put($this->relayStatusFilePath, json_encode($defaultStatus, JSON_PRETTY_PRINT));
    //             return $defaultStatus;
    //         }
    //         $status['relay1'] = strtoupper(isset($status['relay1']) ? $status['relay1'] : 'LOW') === 'HIGH' ? 'HIGH' : 'LOW';
    //         $status['relay2'] = strtoupper(isset($status['relay2']) ? $status['relay2'] : 'LOW') === 'HIGH' ? 'HIGH' : 'LOW';
    //         return $status;
    //     } catch (\Exception $e) {
    //         Log::error('Error reading relay status file.', ['error' => $e->getMessage()]);
    //         return $defaultStatus;
    //     }
    // }

    private function readRelayStatus(): array
    {
        // Tambahkan default untuk perintah reset
        $defaultStatus = [
            'relay1' => 'LOW',
            'relay2' => 'LOW',
            'reset_pzem_energy' => false // <-- Key BARU untuk perintah reset
        ];
        try {
            if (!Storage::disk('local')->exists($this->relayStatusFilePath)) {
                Storage::disk('local')->put($this->relayStatusFilePath, json_encode($defaultStatus, JSON_PRETTY_PRINT));
                return $defaultStatus;
            }
            $jsonContent = Storage::disk('local')->get($this->relayStatusFilePath);
            $status      = json_decode($jsonContent, true);

            if (json_last_error() !== JSON_ERROR_NONE || !is_array($status)) {
                Log::error('Failed to decode relay status JSON or invalid format. Writing default.', ['content' => $jsonContent]);
                Storage::disk('local')->put($this->relayStatusFilePath, json_encode($defaultStatus, JSON_PRETTY_PRINT));
                return $defaultStatus;
            }
            // Gabungkan dengan default untuk memastikan semua key ada
            $status = array_merge($defaultStatus, $status);

            // Validasi nilai relay
            $status['relay1'] = strtoupper($status['relay1']) === 'HIGH' ? 'HIGH' : 'LOW';
            $status['relay2'] = strtoupper($status['relay2']) === 'HIGH' ? 'HIGH' : 'LOW';
            // Pastikan reset_pzem_energy adalah boolean
            $status['reset_pzem_energy'] = filter_var($status['reset_pzem_energy'], FILTER_VALIDATE_BOOLEAN);

            return $status;
        } catch (\Exception $e) {
            Log::error('Error reading relay status file.', ['error' => $e->getMessage()]);
            return $defaultStatus;
        }
    }

    /**
     * Helper function untuk membaca konfigurasi batas dari file JSON.
     */
    private function readLimitConfig(): array
    {
        $costPerKwhEnv = (float) env('COST_PER_KWH', 1444.70);
        $defaultConfig = [
            'is_active'                     => false,
            'limit_value_input'             => 0,
            'limit_type_input'              => 'energy',
            'energy_limit_for_esp'          => 0,
            'cost_per_kwh_at_config'        => $costPerKwhEnv,
            'auto_turn_off_light_on_limit'  => false,
            'light_auto_turned_off'         => false
        ];
        try {
            if (!Storage::disk('local')->exists($this->limitConfigFilePath)) {
                Log::info('Limit config file not found. Creating with default.');
                Storage::disk('local')->put($this->limitConfigFilePath, json_encode($defaultConfig, JSON_PRETTY_PRINT));
                return $defaultConfig;
            }
            $jsonContent = Storage::disk('local')->get($this->limitConfigFilePath);
            $config      = json_decode($jsonContent, true);
            return array_merge($defaultConfig, $config ?: []); // Gabungkan dengan default
        } catch (\Exception $e) {
            Log::error('Error reading limit config file.', ['error' => $e->getMessage()]);
            return $defaultConfig;
        }
    }

    /**
     * Helper function untuk menulis konfigurasi batas ke file JSON.
     */
    private function writeLimitConfig(array $config): bool
    {
        try {
            Storage::disk('local')->put($this->limitConfigFilePath, json_encode($config, JSON_PRETTY_PRINT));
            Log::info('Limit config updated.', $config);
            return true;
        } catch (\Exception $e) {
            Log::error('Failed to update limit config file.', ['error'  => $e->getMessage(), 'config' => $config]);
            return false;
        }
    }

    /**
     * Mengambil data konfigurasi batas saat ini untuk ditampilkan di form web.
     * Endpoint: GET /api/settings/limit/data
     */
    public function getLimitConfigData()
    {
        return response()->json($this->readLimitConfig());
    }

    /**
     * Memperbarui konfigurasi batas pemakaian dari web.
     * Endpoint: POST /api/settings/limit/update
     */
    public function updateLimitConfig(Request $request)
    {
        $validatedData = $request->validate([
            'is_active'                     => 'required|boolean',
            'limit_value_input'             => 'required|numeric|min:0',
            'limit_type_input'              => ['required', Rule::in(['energy', 'cost'])],
            'auto_turn_off_light_on_limit'  => 'required|boolean',
        ]);

        $costPerKwh        = (float) env('COST_PER_KWH', 1444.70);
        $energyLimitForEsp = 0;

        if ($validatedData['limit_type_input'] === 'cost') {
            if ($costPerKwh > 0) {
                $energyLimitForEsp = (float) $validatedData['limit_value_input'] / $costPerKwh;
            } else {
                Log::warning('COST_PER_KWH is zero or not set, cannot calculate energy limit from cost.');
                $energyLimitForEsp = 0;
            }
        } else { // 'energy'
            $energyLimitForEsp = (float) $validatedData['limit_value_input'];
        }

        $oldConfig = $this->readLimitConfig();
        $newConfig = [
            'is_active'                     => (bool) $validatedData['is_active'],
            'limit_value_input'             => (float) $validatedData['limit_value_input'],
            'limit_type_input'              => $validatedData['limit_type_input'],
            'energy_limit_for_esp'          => $energyLimitForEsp,
            'cost_per_kwh_at_config'        => $costPerKwh,
            'auto_turn_off_light_on_limit'  => (bool) $validatedData['auto_turn_off_light_on_limit'],
            'light_auto_turned_off'         => $oldConfig['light_auto_turned_off'] // Pertahankan status lama
        ];

        // Jika fitur auto-off baru saja dinonaktifkan, dan lampu sebelumnya mati otomatis, reset flag
        if (!$newConfig['auto_turn_off_light_on_limit'] && $newConfig['light_auto_turned_off']) {
            $newConfig['light_auto_turned_off'] = false;
        }

        if ($this->writeLimitConfig($newConfig)) {
            return response()->json(['message' => 'Pengaturan batas berhasil diperbarui.','data'    => $this->readLimitConfig()]);
        }
        return response()->json(['message' => 'Gagal memperbarui pengaturan batas.'], 500);
    }

    /**
     * Mengambil konfigurasi batas yang disederhanakan untuk ESP32.
     * Endpoint: GET /api/limit/config
     */
    public function getLimitConfigForEsp()
    {
        $fullConfig = $this->readLimitConfig();
        $espConfig  = ['active' => $fullConfig['is_active'], 'limit_kwh' => $fullConfig['energy_limit_for_esp']];
        return response()->json($espConfig);
    }

    /**
     * Helper untuk membaca status notifikasi email bertingkat.
     */
    private function readEmailNotificationStatus(): array
    {
        $defaultStatus = ['last_notified_state' => 'normal']; // "normal", "approaching", "exceeded"
        try {
            if (!Storage::disk('local')->exists($this->emailNotificationStatusPath)) {
                Storage::disk('local')->put($this->emailNotificationStatusPath, json_encode($defaultStatus, JSON_PRETTY_PRINT));
                Log::info('Tiered email notification status file created with default.');
                return $defaultStatus;
            }
            $jsonContent = Storage::disk('local')->get($this->emailNotificationStatusPath);
            $status      = json_decode($jsonContent, true);
            return array_merge($defaultStatus, $status ?: []); // Gabungkan dengan default
        } catch (\Exception $e) {
            Log::error('Error reading tiered email notification status file.', ['error' => $e->getMessage()]);
            return $defaultStatus;
        }
    }

    /**
     * Helper untuk menulis status notifikasi email bertingkat.
     */
    private function writeEmailNotificationStatus(string $newState): void
    {
        $status = ['last_notified_state' => $newState];
        try {
            Storage::disk('local')->put($this->emailNotificationStatusPath, json_encode($status, JSON_PRETTY_PRINT));
            Log::info('Tiered email notification status updated.', $status);
        } catch (\Exception $e) {
            Log::error('Error writing tiered email notification status file.', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Memeriksa batas pemakaian dan mengirim email bertingkat serta mematikan lampu jika perlu.
     */
    private function checkAndSendTieredUsageLimitEmail(float $currentEnergy, float $currentCost)
    {
        $limitConfig = $this->readLimitConfig();
        $emailNotifyStatus = $this->readEmailNotificationStatus();
        $lastNotifiedState = $emailNotifyStatus['last_notified_state'];

        $recipient = env('NOTIFICATION_EMAIL_RECIPIENT');
        if (!$recipient || !filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
            Log::warning('NOTIFICATION_EMAIL_RECIPIENT is not set or invalid. Cannot send any notification emails.');
            return; // Keluar jika tidak ada penerima valid
        }

        Log::debug('[TieredEmailCheck] Limit Config:', $limitConfig);
        // Log::debug('[TieredEmailCheck] Last Notified State:', $lastNotifiedState);
        Log::debug('[TieredEmailCheck] Last Notified State: ' . $lastNotifiedState); 
        Log::debug('[TieredEmailCheck] Current Energy: ' . $currentEnergy . ' kWh');

        $configChangedForLimitFile = false; // Flag untuk menandai jika limit_config.json (khususnya light_auto_turned_off) diubah

        if ($limitConfig['is_active'] && (float) $limitConfig['energy_limit_for_esp'] > 0.001) {
            $energyTargetLimit = (float) $limitConfig['energy_limit_for_esp'];
            $energyApproachingLimit = $energyTargetLimit * self::APPROACHING_LIMIT_THRESHOLD;
            $costLimitValue = ($limitConfig['limit_type_input'] === 'cost') ? (float) $limitConfig['limit_value_input'] : null;

            $currentState = "normal";
            if ($currentEnergy >= $energyTargetLimit) {
                $currentState = "exceeded";
            } elseif ($currentEnergy >= $energyApproachingLimit) {
                $currentState = "approaching";
            }

            Log::info('[TieredEmailCheck] Determined Current State: ' . $currentState . ' (Prev State: ' . $lastNotifiedState . ')');

            // Logika Kirim Email & Aksi
            if ($currentState === "exceeded") {
                if ($lastNotifiedState !== "exceeded") {
                    try {
                        Mail::to($recipient)->send(new UsageLimitExceededMail(
                            $currentEnergy, $currentCost, $energyTargetLimit,
                            $costLimitValue, $limitConfig['limit_type_input']
                        ));
                        Log::info('Usage EXCEEDED email sent.', ['to' => $recipient]);
                        $this->writeEmailNotificationStatus("exceeded");
                    } catch (\Exception $e) { Log::error('Failed to send EXCEEDED email.', ['error' => $e->getMessage()]); }
                }
                // Logika Auto-Off Lampu
                if ($limitConfig['auto_turn_off_light_on_limit'] && !$limitConfig['light_auto_turned_off']) {
                    Log::info('[AutoOffLight] Exceeded limit & auto-off active. Turning off light.');
                    $currentRelayStatus = $this->readRelayStatus();
                    if ($currentRelayStatus['relay2'] === 'HIGH') { // Hanya matikan jika lampu sedang nyala
                        Storage::disk('local')->put($this->relayStatusFilePath, json_encode(['relay1' => $currentRelayStatus['relay1'], 'relay2' => 'LOW'], JSON_PRETTY_PRINT));
                        Log::info('[AutoOffLight] Relay status updated to turn off light.');
                    }
                    $limitConfig['light_auto_turned_off'] = true;
                    $configChangedForLimitFile = true;
                }

            } elseif ($currentState === "approaching") {
                if ($lastNotifiedState === "normal") { // Hanya kirim jika state sebelumnya "normal"
                    try {
                        Mail::to($recipient)->send(new ApproachingUsageLimitMail(
                            $currentEnergy, $currentCost, $energyTargetLimit,
                            self::APPROACHING_LIMIT_THRESHOLD, $limitConfig['limit_type_input'], $costLimitValue
                        ));
                        Log::info('Usage APPROACHING email sent.', ['to' => $recipient]);
                        $this->writeEmailNotificationStatus("approaching");
                    } catch (\Exception $e) { Log::error('Failed to send APPROACHING email.', ['error' => $e->getMessage()]); }
                }
                // Jika light_auto_turned_off sudah true (karena EXCEEDED), biarkan true.
                // Lampu tidak akan dinyalakan otomatis saat turun dari EXCEEDED ke APPROACHING.

            } elseif ($currentState === "normal") {
                if ($lastNotifiedState === "approaching" || $lastNotifiedState === "exceeded") {
                    try {
                        Mail::to($recipient)->send(new UsageNormalAgainMail($currentEnergy, $currentCost));
                        Log::info('Usage NORMAL AGAIN email sent.', ['to' => $recipient]);
                        $this->writeEmailNotificationStatus("normal");
                    } catch (\Exception $e) { Log::error('Failed to send NORMAL AGAIN email.', ['error' => $e->getMessage()]); }
                }
                // Jika lampu sebelumnya mati otomatis, dan sekarang kembali normal, reset flagnya
                if ($limitConfig['light_auto_turned_off']) {
                    Log::info('[AutoOffLight] Energy back to normal, resetting light_auto_turned_off flag.');
                    $limitConfig['light_auto_turned_off'] = false;
                    $configChangedForLimitFile = true;
                }
            }
        } else { // Fitur batas tidak aktif
            if ($lastNotifiedState !== "normal") {
                $this->writeEmailNotificationStatus("normal"); // Anggap kembali normal
            }
            if ($limitConfig['light_auto_turned_off']) { // Jika fitur batas dinonaktifkan, reset juga flag lampu
                $limitConfig['light_auto_turned_off'] = false;
                $configChangedForLimitFile = true;
            }
        }

        // Simpan perubahan pada limitConfig (khususnya light_auto_turned_off) jika ada
        if ($configChangedForLimitFile) {
            $this->writeLimitConfig($limitConfig);
        }
    }

    /**
     * Menampilkan halaman pengaturan batas pemakaian (JIKA MASIH DIGUNAKAN).
     * Jika UI sudah digabung, method ini dan routenya bisa dihapus.
     */
    public function getLimitSettingsPage()
    {
        Log::warning('getLimitSettingsPage() called, but UI might be merged. Consider removing this route/method if unused.');
        // return view('settings.limit'); // Jika ada view terpisah
        return "Halaman pengaturan batas. (UI mungkin sudah digabung ke dashboard utama)";
    }

    public function showHistory()
    {
        // 1. Mengambil Data Histori dengan Pagination
        // Mengambil data terbaru dulu, dan menampilkan 15 data per halaman
        $historyData = PzemData::latest()->paginate(15);

        // 2. Mengambil Data Akumulasi Bulanan
        $monthlyAccumulation = PzemData::select(
                DB::raw('YEAR(created_at) as year'),
                DB::raw('MONTHNAME(created_at) as month_name'),
                DB::raw('MAX(energi) - MIN(energi) as total_energy_kwh'), // Menghitung selisih energi
                DB::raw('MAX(biaya) - MIN(biaya) as total_cost_rp')     // Menghitung selisih biaya
            )
            ->groupBy('year', 'month_name')
            ->orderBy('year', 'desc')
            ->orderBy(DB::raw('MONTH(created_at)'), 'desc')
            ->get();

        // Mengirim kedua data ke view
        return view('history', [
            'historyData' => $historyData,
            'monthlyAccumulation' => $monthlyAccumulation
        ]);
    }


}