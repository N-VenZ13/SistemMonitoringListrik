<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;
use App\Models\PzemData; // Jika ingin passing data sensor terakhir

class UsageLimitExceededMail extends Mailable implements ShouldQueue // Implements ShouldQueue
{
    use Queueable, SerializesModels;

    public $currentEnergy;
    public $currentCost;
    public $energyLimit;
    public $costLimit; // Jika ingin menampilkan batas biaya juga
    public $limitType; // 'energy' atau 'cost'

    /**
     * Create a new message instance.
     *
     * @param float $currentEnergy
     * @param float $currentCost
     * @param float $energyLimit
     * @param float|null $costLimit
     * @param string $limitType
     */
    public function __construct(float $currentEnergy, float $currentCost, float $energyLimit, $costLimit, string $limitType)
    {
        $this->currentEnergy = $currentEnergy;
        $this->currentCost = $currentCost;
        $this->energyLimit = $energyLimit;
        $this->costLimit = $costLimit;
        $this->limitType = $limitType;
    }

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Peringatan: Batas Pemakaian Listrik Terlampaui!',
        );
    }

    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        return new Content(
            markdown: 'emails.usage_limit_exceeded', // Kita akan buat view ini
            with: [
                'currentEnergy' => $this->currentEnergy,
                'currentCost' => number_format($this->currentCost, 0, ',', '.'),
                'energyLimit' => $this->energyLimit,
                'costLimit' => $this->costLimit ? number_format($this->costLimit, 0, ',', '.') : null,
                'limitType' => $this->limitType,
                'monitoringUrl' => route('monitor.index'), // Link ke halaman monitor
            ],
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        return [];
    }
}