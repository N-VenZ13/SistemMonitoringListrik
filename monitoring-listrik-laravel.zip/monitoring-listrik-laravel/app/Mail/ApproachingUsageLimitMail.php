<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class ApproachingUsageLimitMail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public $currentEnergy;
    public $currentCost;
    public $energyLimit;      // Batas energi target (100%)
    public $approachingThreshold; // Persentase threshold (misal 85%)
    public $limitType;
    public $costLimit; // Batas biaya target (jika tipe 'cost')

    public function __construct(float $currentEnergy, float $currentCost, float $energyLimit, float $approachingThreshold, string $limitType, $costLimit)
    {
        $this->currentEnergy = $currentEnergy;
        $this->currentCost = $currentCost;
        $this->energyLimit = $energyLimit;
        $this->approachingThreshold = $approachingThreshold;
        $this->limitType = $limitType;
        $this->costLimit = $costLimit;
    }

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Peringatan: Pemakaian Listrik Mendekati Batas!',
        );
    }

    public function content(): Content
    {
        return new Content(
            markdown: 'emails.approaching_usage_limit', // View baru
            with: [
                'currentEnergy' => $this->currentEnergy,
                'currentCost' => number_format($this->currentCost, 0, ',', '.'),
                'energyLimit' => $this->energyLimit,
                'approachingThresholdPercent' => $this->approachingThreshold * 100,
                'limitType' => $this->limitType,
                'costLimit' => $this->costLimit ? number_format($this->costLimit, 0, ',', '.') : null,
                'monitoringUrl' => route('monitor.index'),
            ],
        );
    }

    public function attachments(): array
    {
        return [];
    }
}