<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class UsageNormalAgainMail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public $currentEnergy;
    public $currentCost;

    public function __construct(float $currentEnergy, float $currentCost)
    {
        $this->currentEnergy = $currentEnergy;
        $this->currentCost = $currentCost;
    }

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Informasi: Pemakaian Listrik Kembali Normal',
        );
    }

    public function content(): Content
    {
        return new Content(
            markdown: 'emails.usage_normal_again', // View baru
            with: [
                'currentEnergy' => $this->currentEnergy,
                'currentCost' => number_format($this->currentCost, 0, ',', '.'),
                'monitoringUrl' => route('monitor.index'),
            ],
        );
    }

    public function attachments(): array
    {
        return [];
    }
}