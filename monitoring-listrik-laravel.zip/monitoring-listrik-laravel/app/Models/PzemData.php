<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PzemData extends Model
{
    use HasFactory;

    /**
     * Nama tabel yang terhubung dengan model.
     *
     * @var string
     */
    protected $table = 'pzem_data';

    /**
     * Atribut yang bisa diisi secara massal.
     * Kita akan mengisi 'biaya' secara terpisah setelah perhitungan.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'tegangan',
        'arus',
        'daya',
        'energi',
        'biaya', // Tambahkan biaya ke fillable
    ];

    /**
     * Atribut yang harus di-cast ke tipe data asli.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'tegangan' => 'float',
        'arus' => 'float',
        'daya' => 'float',
        'energi' => 'float',
        'biaya' => 'decimal:2', // Pastikan biaya di-cast sebagai desimal
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}