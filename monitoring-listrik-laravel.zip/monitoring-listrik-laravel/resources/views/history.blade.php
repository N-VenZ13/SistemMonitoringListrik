<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Histori & Akumulasi Pemakaian Listrik</title>

    <!-- === TAMBAHKAN LINK CSS BOOTSTRAP DI SINI === -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        /* (Tambahkan CSS yang mirip dengan monitor.blade.php untuk konsistensi) */
        body { margin: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f6f8; color: #2c3e50; }
        header { background-color: #34495e; color: #ecf0f1; padding: 20px 40px; text-align: center; font-size: 1.8em; font-weight: bold; }
        main { padding: 30px 40px; }
        .card { background: white; border-radius: 16px; padding: 20px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08); margin-bottom: 30px; }
        h2 { border-bottom: 2px solid #34495e; padding-bottom: 10px; margin-top: 0; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 12px 15px; border: 1px solid #ddd; text-align: left; }
        th { background-color: #f4f6f8; font-weight: bold; }
        tbody tr:nth-child(even) { background-color: #f9f9f9; }
        
        .back-link { display: inline-block; margin-bottom: 20px; text-decoration: none; background-color: #6c5ce7; color: white; padding: 10px 15px; border-radius: 5px; }
    </style>
</head>
<body>
    <header>📜 Histori & Laporan Pemakaian Listrik</header>
    <main>
        <a href="{{ route('monitor.index') }}" class="back-link">← Kembali ke Dashboard</a>

        <div class="card">
            <h2>Akumulasi Penggunaan per Bulan</h2>
            <table>
                <thead>
                    <tr>
                        <th>Bulan</th>
                        <th>Total Pemakaian Energi</th>
                        <th>Estimasi Total Biaya</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($monthlyAccumulation as $data)
                        <tr>
                            <td>{{ $data->month_name }} {{ $data->year }}</td>
                            <td>{{ number_format($data->total_energy_kwh, 3, ',', '.') }} kWh</td>
                            <td>Rp {{ number_format($data->total_cost_rp, 0, ',', '.') }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="3" style="text-align: center;">Belum ada data akumulasi yang cukup.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="card">
            <h2>Detail Histori Pemakaian</h2>
            <table>
                <thead>
                    <tr>
                        <th>Waktu</th>
                        <th>Tegangan (V)</th>
                        <th>Arus (A)</th>
                        <th>Daya (W)</th>
                        <th>Energi (kWh)</th>
                        <th>Biaya (Rp)</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($historyData as $log)
                        <tr>
                            <td>{{ $log->created_at->format('d M Y, H:i:s') }}</td>
                            <td>{{ number_format($log->tegangan, 3, ',', '.') }}</td>
                            <td>{{ number_format($log->arus, 3, ',', '.') }}</td>
                            <td>{{ number_format($log->daya, 3, ',', '.') }}</td>
                            <td>{{ number_format($log->energi, 3, ',', '.') }}</td>
                            <td>{{ number_format($log->biaya, 0, ',', '.') }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" style="text-align: center;">Tidak ada data histori.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
            <!-- Menampilkan link pagination -->
            <div class="d-flex justify-content-center">
                {{ $historyData->links() }}
            </div>
        </div>
    </main>
</body>
</html>