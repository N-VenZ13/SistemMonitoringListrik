@component('mail::message')
# Peringatan: Pemakaian Listrik Mendekati Batas!

Halo,

Sistem monitoring listrik kami mendeteksi bahwa pemakaian listrik Anda saat ini telah mencapai **{{ $approachingThresholdPercent }}%** dari batas yang telah ditetapkan dan sudah **mendekati batas target**.

**Detail Pemakaian Saat Ini:**
- Energi Terpakai: **{{ $currentEnergy }} kWh**
- Estimasi Biaya Saat Ini: **Rp {{ $currentCost }}**

**Batas Target yang Ditetapkan:**
@if($limitType === 'energy')
- Batas Energi Target: **{{ $energyLimit }} kWh**
@else
- Batas Biaya Target: **Rp {{ $costLimit }}** (Perkiraan setara dengan {{ $energyLimit }} kWh)
@endif

Mohon untuk mulai memperhatikan penggunaan perangkat listrik Anda agar konsumsi tidak melebihi batas.

@component('mail::button', ['url' => $monitoringUrl, 'color' => 'warning'])
Lihat Dashboard Monitoring
@endcomponent

Terima kasih,<br>
Tim {{ config('app.name') }}
@endcomponent