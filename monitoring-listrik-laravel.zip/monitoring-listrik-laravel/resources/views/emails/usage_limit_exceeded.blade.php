@component('mail::message')
# Peringatan Batas Pemakaian Listrik Terlampaui!

Halo,

Sistem monitoring listrik kami mendeteksi bahwa pemakaian listrik Anda telah melebihi batas yang telah ditetapkan.

**Detail Pemakaian Saat Ini:**
- Energi Terpakai: **{{ $currentEnergy }} kWh**
- Estimasi Biaya Saat Ini: **Rp {{ $currentCost }}**

**Batas yang Ditetapkan:**
@if($limitType === 'energy')
- Batas Energi: **{{ $energyLimit }} kWh**
@elseif($limitType === 'cost' && isset($costLimit))
- Batas Biaya: **Rp {{ $costLimit }}** (Perkiraan setara dengan {{ $energyLimit }} kWh pada tarif saat ini)
@else
- Batas Energi (dihitung): **{{ $energyLimit }} kWh**
@endif

Mohon untuk segera memeriksa penggunaan perangkat listrik Anda untuk mengelola konsumsi agar tidak melebihi anggaran atau target pemakaian energi Anda.

Anda dapat melihat detail penggunaan dan mengelola pengaturan melalui dashboard monitoring kami.

@component('mail::button', ['url' => $monitoringUrl, 'color' => 'primary'])
Lihat Dashboard Monitoring
@endcomponent

Terima kasih atas perhatian Anda.

Hormat kami,<br>
Tim {{ config('app.name') }}
@endcomponent