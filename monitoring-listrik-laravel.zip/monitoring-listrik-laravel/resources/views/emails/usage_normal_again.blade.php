@component('mail::message')
# Informasi: Pemakaian Listrik Kembali Normal

Halo,

Sistem monitoring listrik kami menginformasikan bahwa pemakaian listrik Anda saat ini telah kembali ke tingkat normal (di bawah ambang batas peringatan).

**Detail Pemakaian Saat Ini:**
- Energi Terpakai: **{{ $currentEnergy }} kWh**
- Estimasi Biaya Saat Ini: **Rp {{ $currentCost }}**

Terima kasih telah mengelola penggunaan energi Anda.

@component('mail::button', ['url' => $monitoringUrl, 'color' => 'success'])
Lihat Dashboard Monitoring
@endcomponent

Salam hemat energi,<br>
Tim {{ config('app.name') }}
@endcomponent