<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Dashboard Monitoring & Kontrol Listrik</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * { box-sizing: border-box; }
        body { margin: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f6f8; color: #2c3e50; }
        header { background-color: #34495e; color: #ecf0f1; padding: 20px 40px; text-align: center; font-size: 1.8em; font-weight: bold; }
        main { padding: 30px 40px; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .card { background: white; border-radius: 16px; padding: 20px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08); text-align: center; transition: transform 0.2s ease-in-out; }
        .card:hover { transform: translateY(-5px); }
        .card h3 { margin: 0 0 10px 0; font-size: 1.1em; color: #7f8c8d; text-transform: uppercase; letter-spacing: 0.5px; }
        .card span.value { font-size: 2.2em; font-weight: bold; display: block; margin-top: 5px; color: #2d3436; line-height: 1.2; }
        .card span.unit { font-size: 0.9em; color: #7f8c8d; margin-left: 5px; }
        
        .control-card { /* Menggantikan relay-card */
            background-color: #ffffff; 
            border-left: 6px solid #6c5ce7; 
            padding: 25px; 
            margin-bottom: 30px;
            display: flex;
            flex-direction: column; /* Agar judul dan tombol tersusun vertikal jika perlu */
            align-items: center; /* Pusatkan konten */
        }
        .control-group h3 { /* Menggantikan relay-group */
            margin-bottom: 15px; 
            color: #2d3436; 
            font-size: 1.3em; /* Sedikit lebih besar */
        }
        .control-button { /* Menggantikan relay-button */
            background-color: #dfe6e9; 
            color: #2d3436; 
            border: 2px solid transparent; 
            padding: 10px 20px; 
            border-radius: 8px; 
            font-size: 1em; 
            font-weight: 600; 
            cursor: pointer; 
            margin: 0 5px; 
            transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease; 
        }
        .control-button.on { background-color: #00b894; color: white; border-color: #00a884; }
        .control-button.off { background-color: #d63031; color: white; border-color: #c62828; }
        .control-button:hover:not(.on):not(.off) { background-color: #b2bec3; }
        .control-button.on:hover { background-color: #00a884; }
        .control-button.off:hover { background-color: #c62828; }

        .chart-container { margin-top: 30px; background: white; border-radius: 16px; padding: 25px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08); }
        footer { text-align: center; color: #95a5a6; font-size: 0.9em; padding: 30px 20px; margin-top: 40px; border-top: 1px solid #dfe6e9; }

        .settings-card { background-color: #ffffff; border-left: 6px solid #f39c12; padding: 25px; margin-bottom: 30px; }
        .settings-card > h3 { margin-top: 0; margin-bottom: 25px; color: #2d3436; text-align: center; font-size: 1.4em; }
        .form-group { margin-bottom: 20px; text-align: left; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 600; color: #555; }
        .form-group input[type="number"], .form-group select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; font-size: 1em; }
        .form-group .toggle-switch { position: relative; display: inline-block; width: 60px; height: 34px; margin-top: 5px; }
        .form-group .toggle-switch input { opacity: 0; width: 0; height: 0; }
        .form-group .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .4s; border-radius: 34px; }
        .form-group .slider:before { position: absolute; content: ""; height: 26px; width: 26px; left: 4px; bottom: 4px; background-color: white; transition: .4s; border-radius: 50%; }
        .form-group input:checked + .slider { background-color: #2196F3; }
        .form-group input:checked + .slider:before { transform: translateX(26px); }
        .settings-card button[type="submit"] { background-color: #f39c12; color: white; padding: 12px 25px; border: none; border-radius: 4px; cursor: pointer; font-size: 1em; font-weight: 600; display: block; margin: 25px auto 0 auto; transition: background-color 0.3s ease; }
        .settings-card button[type="submit"]:hover { background-color: #e67e22; }
        .status-message { margin-top: 15px; padding: 10px; border-radius: 4px; text-align: center; font-weight: 500;}
        .success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb;}
        .error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb;}
        .card-link a h3 {
        text-decoration: none;
        color: #ffffff;
        display: inline-block;
        font-size: 1rem;
        padding: 8px 24px;
        border-radius: 4px;
        background-color: #f1c40f;
        text-transform: none;
        
        transition: all 0.2s ease;
    }
    .card-link a:hover h3 {
        color: #ffffff;
        transform: scale(1.05);
        text-transform: none;
    }
    .card-link {
        
        color: #ffffff;
        
        padding: 10px;
        margin-bottom: 10px;
    }
    .value-update {
    transition: all 0.1s ease-in-out;
    transform: scale(1.1);
    color: #2ecc71; /* Warna hijau untuk update */
}

    </style>
</head>
<body>
    <header>⚡ Monitoring & Kontrol Listrik Rumah</header>
    <main>
        <div class="grid">
            <div class="card">
                <h3>Tegangan</h3>
                <span class="value" id="tegangan">0.00</span><span class="unit"> V</span>
            </div>
            <div class="card">
                <h3>Arus</h3>
                <span class="value" id="arus">0.000</span><span class="unit"> A</span>
            </div>
            <div class="card">
                <h3>Daya</h3>
                <span class="value" id="daya">0.00</span><span class="unit"> W</span>
            </div>
            <div class="card">
                <h3>Energi</h3>
                <span class="value" id="energi">0.000</span><span class="unit"> kWh</span>
            </div>
            <div class="card">
                <h3>Estimasi Biaya</h3>
                <span class="unit">Rp</span> <span class="value" id="biaya">0</span>
            </div>
        </div>

        <div class="card control-card">
             <div class="control-group">
                <h3>Kontrol Lampu</h3>
                <button class="control-button" id="lampu-on" data-relay-target="relay2" data-state="HIGH">NYALA</button>
                <button class="control-button" id="lampu-off" data-relay-target="relay2" data-state="LOW">MATI</button>
                <span id="lampu-status" style="display: block; margin-top: 8px; font-size: 0.9em; color: #7f8c8d;">Status: Unknown</span>
             </div>
        </div>

        <div class="card settings-card">
            <h3>Pengaturan Batas Pemakaian</h3>
            <form id="limitSettingsForm">
                <div class="form-group">
                    <label for="limit_is_active">Aktifkan Batas Pemakaian:</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="limit_is_active" name="is_active">
                        <span class="slider"></span>
                    </label>
                </div>
                <div class="form-group">
                    <label for="limit_value_input">Nilai Batas:</label>
                    <input type="number" id="limit_value_input" name="limit_value_input" step="any" min="0" required>
                </div>
                <div class="form-group">
                    <label for="limit_type_input">Tipe Batas:</label>
                    <select id="limit_type_input" name="limit_type_input">
                        <option value="energy">Energi (kWh)</option>
                        <option value="cost">Biaya (Rp)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="limit_auto_turn_off_light">Otomatis Matikan Lampu Saat Batas Terlampaui:</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="limit_auto_turn_off_light" name="auto_turn_off_light_on_limit">
                        <span class="slider"></span>
                    </label>
                </div>
                <button type="submit">Simpan Pengaturan Batas</button>
            </form>
            <div id="limitStatusMessage" class="status-message" style="display:none;"></div>
        </div>

        <div class="chart-container">
            <h3>Grafik Monitoring</h3>
            <canvas id="monitorChart" height="100"></canvas>
        </div>

         <!-- Tombol Reset Energi PZEM -->
        <div class="card" style="margin-top: 30px; text-align: center;">
            <h3>Reset Data Sensor PZEM</h3>
            <p style="font-size: 0.9em; color: #555; margin-bottom: 15px;">
                
            </p>
            <button id="resetPzemButton" class="control-button off" style="background-color: #e74c3c; color:white; border-color: #c0392b;">
                Reset Energi PZEM
            </button>
            <div id="resetPzemStatus" style="margin-top: 10px; font-size: 0.9em;"></div>
        </div>

        <!-- Card baru untuk link ke Halaman Histori -->
            <div class="card card-link">
                <h3>Cek Laporan Bulanan & Histori</h3>
                <a href="{{ route('history.show') }}">
                    <h3>Laporan & Histori</h3>
                </a>
            </div>



    </main>
    <footer>© {{ date('Y') }} Novendri - Sistem Monitoring Listrik</footer>

<script>
    const MAX_DATA_POINTS = 60;
    const labels = [];
    const teganganData = [];
    const arusData = [];
    const dayaData = [];

    const ctx = document.getElementById('monitorChart').getContext('2d');
    const monitorChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                { label: 'Tegangan (V)', data: teganganData, borderColor: '#3498db', tension: 0.1, fill: false },
                { label: 'Arus (A)', data: arusData, borderColor: '#2ecc71', tension: 0.1, fill: false },
                { label: 'Daya (W)', data: dayaData, borderColor: '#e74c3c', tension: 0.1, fill: false }
            ]
        },
        options: { responsive: true, maintainAspectRatio: true, animation: false, scales: { x: { title: { display: true, text: 'Waktu' } }, y: { beginAtZero: true, title: { display: true, text: 'Nilai' } } }, plugins: { legend: { position: 'top' } } }
    });

    let currentRelayStatus = { relay1: 'LOW', relay2: 'UNKNOWN' }; // relay1 tetap ada untuk konsistensi payload
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    /*function updateUI(data) {
        const sensor = data.sensor || {};
        document.getElementById('tegangan').textContent = sensor.tegangan?.toFixed(2) ?? 'N/A';
        document.getElementById('arus').textContent = sensor.arus?.toFixed(3) ?? 'N/A';
        document.getElementById('daya').textContent = sensor.daya?.toFixed(2) ?? 'N/A';
        document.getElementById('energi').textContent = sensor.energi?.toFixed(3) ?? 'N/A';
        document.getElementById('biaya').textContent = sensor.biaya ? parseFloat(sensor.biaya).toLocaleString('id-ID', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) : 'N/A';

        const relay = data.relay || { relay1: 'LOW', relay2: 'LOW' };
        currentRelayStatus = relay; // Update status global
        
        updateControlButtonStyling('lampu', relay.relay2);
        document.getElementById('lampu-status').textContent = `Status Lampu: ${relay.relay2 === 'HIGH' ? 'NYALA' : 'MATI'}`;

        if (sensor.created_at) {
            const now = new Date(sensor.created_at).toLocaleTimeString('id-ID');
            if (labels.length >= MAX_DATA_POINTS) { labels.shift(); teganganData.shift(); arusData.shift(); dayaData.shift(); }
            labels.push(now);
            teganganData.push(sensor.tegangan ?? 0);
            arusData.push(sensor.arus ?? 0);
            dayaData.push(sensor.daya ?? 0);
            monitorChart.update();
        }
        
        
    }*/

   

function updateUI(data) {
    const sensor = data.sensor || {}; // Fallback ke objek kosong jika tidak ada data sensor

    /**
     * Helper function untuk mengupdate nilai di elemen HTML
     * dan memberikan efek visual singkat.
     * @param {string} elementId - ID dari elemen span yang berisi nilai.
     * @param {string} newValue - Nilai baru yang akan ditampilkan.
     * @param {string} effectClass - Nama class CSS untuk efek visual.
     */
    function updateValueWithEffect(elementId, newValue, effectClass) {
        const element = document.getElementById(elementId);
        if (!element) return; // Keluar jika elemen tidak ditemukan

        // Hanya beri efek jika nilainya benar-benar berubah dari sebelumnya
        if (element.textContent !== newValue) {
            element.textContent = newValue;
            
            // Tambahkan class untuk efek, lalu hapus setelah beberapa saat
            element.classList.add(effectClass);
            setTimeout(() => {
                element.classList.remove(effectClass);
            }, 300); // Durasi efek 300 milidetik
        } else {
            // Jika nilainya sama, cukup pastikan nilainya tetap diupdate tanpa efek
            element.textContent = newValue;
        }
    }

    // --- Menggunakan helper function untuk update setiap card ---

    // Tegangan, Arus, Daya (3 desimal untuk presisi)
    updateValueWithEffect('tegangan', sensor.tegangan?.toFixed(3) ?? 'N/A', 'value-update');
    updateValueWithEffect('arus', sensor.arus?.toFixed(3) ?? 'N/A', 'value-update');
    updateValueWithEffect('daya', sensor.daya?.toFixed(3) ?? 'N/A', 'value-update');

    // Energi (5 desimal untuk melihat perubahan kecil)
    updateValueWithEffect('energi', sensor.energi?.toFixed(5) ?? 'N/A', 'value-update');
    
    // Biaya (2 desimal untuk melihat perubahan rupiah)
    const formattedBiaya = sensor.biaya ?
        parseFloat(sensor.biaya).toLocaleString('id-ID', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : 'N/A';
    updateValueWithEffect('biaya', formattedBiaya, 'value-update');


    // --- Update bagian lain (status lampu & grafik) ---

    // Update Status & Tombol Lampu (logika ini tetap sama)
    const relay = data.relay || { relay1: 'LOW', relay2: 'LOW' };
    currentRelayStatus = relay;
    updateControlButtonStyling('lampu', relay.relay2);
    document.getElementById('lampu-status').textContent = `Status Lampu: ${relay.relay2 === 'HIGH' ? 'NYALA' : 'MATI'}`;

    // Update Grafik (logika ini tetap sama)
    if (sensor.created_at) {
        const now = new Date(sensor.created_at).toLocaleTimeString('id-ID');

        if (labels.length >= MAX_DATA_POINTS) {
            labels.shift();
            teganganData.shift();
            arusData.shift();
            dayaData.shift();
        }

        labels.push(now);
        // Data untuk grafik tetap angka murni, tidak diformat
        teganganData.push(sensor.tegangan ?? 0);
        arusData.push(sensor.arus ?? 0);
        dayaData.push(sensor.daya ?? 0);

        monitorChart.update();
    }
}

    function updateControlButtonStyling(prefix, state) {
         const btnOn = document.getElementById(`${prefix}-on`);
         const btnOff = document.getElementById(`${prefix}-off`);
         btnOn.classList.remove('on', 'off'); btnOff.classList.remove('on', 'off');
         if (state === 'HIGH') { btnOn.classList.add('on'); }
         else if (state === 'LOW') { btnOff.classList.add('off'); }
    }

    async function fetchData() {
        try {
            const response = await fetch("{{ route('monitor.data') }}");
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            const data = await response.json();
            updateUI(data);
        } catch (error) { console.error("Gagal fetch data:", error); }
    }

    async function sendLampControl(newState) {
        const payload = {
            relay1: currentRelayStatus.relay1, // Tetap kirim status relay1 (misal, selalu LOW)
            relay2: newState // State baru untuk relay2 (lampu)
        };
        const oldStateRelay2 = currentRelayStatus.relay2;
        currentRelayStatus.relay2 = newState; // Optimistic update
        updateControlButtonStyling('lampu', newState);
        document.getElementById('lampu-status').textContent = `Status Lampu: Sending...`;

        try {
            const response = await fetch("{{ route('relay.control') }}", {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken, 'Accept': 'application/json' },
                body: JSON.stringify(payload)
            });
            const result = await response.json();
            if (!response.ok) {
                 currentRelayStatus.relay2 = oldStateRelay2; // Revert
                 updateControlButtonStyling('lampu', oldStateRelay2);
                 document.getElementById('lampu-status').textContent = `Status Lampu: Failed!`;
                 alert(`Gagal mengubah status lampu: ${result.message || 'Error tidak diketahui'}`);
            } else {
                 currentRelayStatus = result.data; // Update dari server
                 updateControlButtonStyling('lampu', currentRelayStatus.relay2);
                 document.getElementById('lampu-status').textContent = `Status Lampu: ${currentRelayStatus.relay2 === 'HIGH' ? 'NYALA' : 'MATI'}`;
            }
        } catch (error) {
            currentRelayStatus.relay2 = oldStateRelay2; // Revert
            updateControlButtonStyling('lampu', oldStateRelay2);
            document.getElementById('lampu-status').textContent = `Status Lampu: Network Error!`;
            alert('Gagal mengirim perintah kontrol lampu. Cek koneksi.');
        }
    }

    const limitSettingsForm = document.getElementById('limitSettingsForm');
    const limitStatusMessageEl = document.getElementById('limitStatusMessage');

    async function loadCurrentLimitSettings() {
        try {
            const response = await fetch("{{ route('settings.limit.data.api') }}");
            if (!response.ok) throw new Error('Gagal mengambil data pengaturan batas.');
            const data = await response.json();
            document.getElementById('limit_is_active').checked = data.is_active;
            document.getElementById('limit_value_input').value = data.limit_value_input;
            document.getElementById('limit_type_input').value = data.limit_type_input;
            document.getElementById('limit_auto_turn_off_light').checked = data.auto_turn_off_light_on_limit;
        } catch (error) {
            console.error('Error loading limit settings:', error);
            showLimitStatus(`Error ambil data: ${error.message}`, 'error');
        }
    }

    if (limitSettingsForm) {
        limitSettingsForm.addEventListener('submit', async function(event) {
            event.preventDefault();
            showLimitStatus('Menyimpan...', '');
            const formData = {
                is_active: document.getElementById('limit_is_active').checked,
                limit_value_input: parseFloat(document.getElementById('limit_value_input').value),
                limit_type_input: document.getElementById('limit_type_input').value,
                auto_turn_off_light_on_limit: document.getElementById('limit_auto_turn_off_light').checked,
            };
            try {
                const response = await fetch("{{ route('settings.limit.update.api') }}", {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken, 'Accept': 'application/json' },
                    body: JSON.stringify(formData)
                });
                const result = await response.json();
                if (!response.ok) throw new Error(result.message || 'Gagal menyimpan pengaturan batas.');
                showLimitStatus(result.message || 'Pengaturan batas berhasil disimpan.', 'success');
                 // Reload data limit config untuk memastikan UI form sinkron dengan state server setelah disimpan
                loadCurrentLimitSettings();
            } catch (error) {
                console.error('Error saving limit settings:', error);
                showLimitStatus(`Error simpan: ${error.message}`, 'error');
            }
        });
    }

    function showLimitStatus(message, type) {
        limitStatusMessageEl.textContent = message;
        limitStatusMessageEl.className = 'status-message';
        if (type) { limitStatusMessageEl.classList.add(type); }
        limitStatusMessageEl.style.display = message ? 'block' : 'none';
    }


    // --- JavaScript untuk Tombol Reset PZEM ---
    const resetPzemButton = document.getElementById('resetPzemButton');
    const resetPzemStatusEl = document.getElementById('resetPzemStatus');

    if (resetPzemButton) {
        resetPzemButton.addEventListener('click', async function() {
            if (!confirm("Apakah Anda yakin ingin mereset data energi dan biaya di sensor PZEM?")) {
                return;
            }

            resetPzemStatusEl.textContent = 'Mengirim perintah reset...';
            resetPzemStatusEl.style.color = '#7f8c8d';
            this.disabled = true; // Nonaktifkan tombol sementara

            try {
                const response = await fetch("{{ route('pzem.command.reset') }}", { // Kita akan buat route ini
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': csrfToken, // csrfToken sudah didefinisikan di atas
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({}) // Body bisa kosong jika tidak ada data tambahan
                });

                const result = await response.json();

                if (!response.ok) {
                    throw new Error(result.message || 'Gagal mengirim perintah reset.');
                }
                resetPzemStatusEl.textContent = result.message || 'Perintah reset berhasil dikirim. Sensor akan direset pada siklus berikutnya.';
                resetPzemStatusEl.style.color = 'green';

            } catch (error) {
                console.error('Error sending reset command:', error);
                resetPzemStatusEl.textContent = 'Error: ' + error.message;
                resetPzemStatusEl.style.color = 'red';
            } finally {
                // Aktifkan kembali tombol setelah beberapa saat untuk mencegah double click cepat
                setTimeout(() => {
                    resetPzemButton.disabled = false;
                    // Bisa juga reset pesan status setelah beberapa detik lagi
                    // setTimeout(() => { resetPzemStatusEl.textContent = ''; }, 5000);
                }, 3000);
            }
        });
    }



    window.onload = function () {
        fetchData();
        setInterval(fetchData, 3000);

        if (limitSettingsForm) {
            loadCurrentLimitSettings();
        }

        document.getElementById('lampu-on').addEventListener('click', function() {
            const newState = this.dataset.state; // "HIGH"
            if (newState !== currentRelayStatus.relay2) { // Hanya kirim jika state berbeda
                sendLampControl(newState);
            }
        });
        document.getElementById('lampu-off').addEventListener('click', function() {
            const newState = this.dataset.state; // "LOW"
             if (newState !== currentRelayStatus.relay2) { // Hanya kirim jika state berbeda
                sendLampControl(newState);
            }
        });
    };
</script>
</body>
</html>