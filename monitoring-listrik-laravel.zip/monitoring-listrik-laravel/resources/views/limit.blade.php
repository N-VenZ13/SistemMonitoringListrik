<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Pengaturan Batas Pemakaian</title>
    <style>
        body { font-family: sans-serif; margin: 20px; background-color: #f4f6f8; }
        .container { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); max-width: 500px; margin: auto; }
        label { display: block; margin-bottom: 8px; font-weight: bold; color: #333; }
        input[type="number"], select { width: 100%; padding: 10px; margin-bottom: 20px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        .toggle-switch { position: relative; display: inline-block; width: 60px; height: 34px; margin-bottom: 20px;}
        .toggle-switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .4s; border-radius: 34px; }
        .slider:before { position: absolute; content: ""; height: 26px; width: 26px; left: 4px; bottom: 4px; background-color: white; transition: .4s; border-radius: 50%; }
        input:checked + .slider { background-color: #2196F3; }
        input:checked + .slider:before { transform: translateX(26px); }
        button { background-color: #28a745; color: white; padding: 12px 20px; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        button:hover { background-color: #218838; }
        .status-message { margin-top: 15px; padding: 10px; border-radius: 4px; }
        .success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb;}
        .error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb;}
        h1 { text-align: center; color: #34495e; margin-bottom: 30px;}
    </style>
</head>
<body>
    <div class="container">
        <h1>Pengaturan Batas Pemakaian</h1>
        <form id="limitSettingsForm">
            <div>
                <label for="is_active">Aktifkan Batas Pemakaian:</label>
                <label class="toggle-switch">
                    <input type="checkbox" id="is_active" name="is_active">
                    <span class="slider"></span>
                </label>
            </div>

            <div>
                <label for="limit_value_input">Nilai Batas:</label>
                <input type="number" id="limit_value_input" name="limit_value_input" step="any" required>
            </div>

            <div>
                <label for="limit_type_input">Tipe Batas:</label>
                <select id="limit_type_input" name="limit_type_input">
                    <option value="energy">Energi (kWh)</option>
                    <option value="cost">Biaya (Rp)</option>
                </select>
            </div>

            <button type="submit">Simpan Pengaturan</button>
        </form>
        <div id="statusMessage" class="status-message" style="display:none;"></div>
    </div>

<script>
    const form = document.getElementById('limitSettingsForm');
    const statusMessageEl = document.getElementById('statusMessage');
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    async function loadCurrentSettings() {
        try {
            // Gunakan route name dari api.php
            const response = await fetch("{{ route('settings.limit.data.api') }}");
            if (!response.ok) throw new Error('Gagal mengambil data pengaturan.');
            const data = await response.json();

            document.getElementById('is_active').checked = data.is_active;
            document.getElementById('limit_value_input').value = data.limit_value_input;
            document.getElementById('limit_type_input').value = data.limit_type_input;

        } catch (error) {
            console.error('Error loading settings:', error);
            showStatus(`Error: ${error.message}`, 'error');
        }
    }

    form.addEventListener('submit', async function(event) {
        event.preventDefault();
        showStatus('Menyimpan...', ''); // Clear previous message

        const formData = {
            is_active: document.getElementById('is_active').checked,
            limit_value_input: parseFloat(document.getElementById('limit_value_input').value),
            limit_type_input: document.getElementById('limit_type_input').value,
        };

        try {
            // Gunakan route name dari api.php
            const response = await fetch("{{ route('settings.limit.update.api') }}", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken,
                    'Accept': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.message || 'Gagal menyimpan pengaturan.');
            }
            showStatus(result.message || 'Pengaturan berhasil disimpan.', 'success');

        } catch (error) {
            console.error('Error saving settings:', error);
            showStatus(`Error: ${error.message}`, 'error');
        }
    });

    function showStatus(message, type) {
        statusMessageEl.textContent = message;
        statusMessageEl.className = 'status-message'; // Reset class
        if (type) {
            statusMessageEl.classList.add(type);
        }
        statusMessageEl.style.display = message ? 'block' : 'none';
    }

    window.onload = loadCurrentSettings;
</script>
</body>
</html>